

	
		
		
		
select * from BrandInfo order by bm_no desc;

drop table BrandInfo purge;



