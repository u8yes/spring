package com.spring.proj.domain.comu;

import java.sql.Date;

public class ReplyVO {

	private int r_no;
	private int cm_bdno;
	private String r_content;
	private String r_del;
	private String r_date;
	private String r_writer;
	
	public int getR_no() {
		return r_no;
	}
	public void setR_no(int r_no) {
		this.r_no = r_no;
	}
	public int getCm_bdno() {
		return cm_bdno;
	}
	public void setCm_bdno(int cm_bdno) {
		this.cm_bdno = cm_bdno;
	}
	public String getR_content() {
		return r_content;
	}
	public void setR_content(String r_content) {
		this.r_content = r_content;
	}
	public String getR_del() {
		return r_del;
	}
	public void setR_del(String r_del) {
		this.r_del = r_del;
	}
	public String getR_date() {
		return r_date;
	}
	public void setR_date(String r_date) {
		this.r_date = r_date;
	}
	public String getR_writer() {
		return r_writer;
	}
	public void setR_writer(String r_writer) {
		this.r_writer = r_writer;
	}
	
	
	
	
}
