package com.spring.proj.domain.buy;

import lombok.Data;

@Data
public class BuyToVO {

	private int amount;
	private int sum;
	
}
